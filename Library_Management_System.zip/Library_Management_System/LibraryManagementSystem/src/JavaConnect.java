/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author shivakant
 */
import java.sql.*;  
public class JavaConnect {
    public static void main(String args[]) throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql:///mydatabase","root","Root@123");
    
       new NewAccount().setVisible(true);
    }
}  
    

