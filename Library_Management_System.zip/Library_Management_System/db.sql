-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: mydatabase
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account` (
  `User_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(35) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `Security_key` varchar(50) NOT NULL,
  `Answer` varchar(50) NOT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12346 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
INSERT INTO `Account` VALUES (1,'dilip','123','What is your nick Name?','dk'),(2,'dilip','123','What is your nick Name?','dk'),(9,'ram','ram','What is your mother Tonguee?','HIndi'),(11,'jai','12345','What is your mother Tonguee?','Hindi'),(12,'jai','12345','What is your mother Tonguee?','Hindi'),(123,'Shiwa','12345','What is your mother Tonguee?','Hindi'),(126,'Shiwakant','12345','What is your nick Name?','shivoo'),(312,'Ram','123456','What is your mother Tonguee?','Hindi'),(321,'Ram','12345','What is your mother Tonguee?','Hindi'),(543,'Shiwa','2314','What is your mother Tonguee?','Hindi'),(12345,'Ram','32145','What is your nick Name?','Shree');
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Book`
--

DROP TABLE IF EXISTS `Book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Book` (
  `Book_ID` int(10) NOT NULL,
  `Name` varchar(40) DEFAULT NULL,
  `Edition` int(10) DEFAULT NULL,
  `Publisher` varchar(30) DEFAULT NULL,
  `Price` int(10) DEFAULT NULL,
  `Pages` int(10) DEFAULT NULL,
  PRIMARY KEY (`Book_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Book`
--

LOCK TABLES `Book` WRITE;
/*!40000 ALTER TABLE `Book` DISABLE KEYS */;
INSERT INTO `Book` VALUES (4064,'Ramayan',1,'Ramanand',500,500),(4142,'ds',3,'pk sinha',200,100),(4811,'Java',1,'MC Graw Hill',500,500),(6787,'Ram',1,'Jai',234,65),(8393,'java',1,'java',200,400);
/*!40000 ALTER TABLE `Book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Issue_Book`
--

DROP TABLE IF EXISTS `Issue_Book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Issue_Book` (
  `Book_ID` int(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Edition` int(10) NOT NULL,
  `Publisher` varchar(30) NOT NULL,
  `Price` int(10) NOT NULL,
  `Pages` int(10) NOT NULL,
  `Student_ID` int(10) NOT NULL,
  `Student_Name` varchar(40) NOT NULL,
  `Father_Name` varchar(30) NOT NULL,
  `Course` varchar(30) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `Year` int(10) NOT NULL,
  `Semester` int(10) DEFAULT NULL,
  `Date_Of_Issue` date DEFAULT NULL,
  PRIMARY KEY (`Book_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Issue_Book`
--

LOCK TABLES `Issue_Book` WRITE;
/*!40000 ALTER TABLE `Issue_Book` DISABLE KEYS */;
/*!40000 ALTER TABLE `Issue_Book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Return_Book`
--

DROP TABLE IF EXISTS `Return_Book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Return_Book` (
  `Student_ID` int(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Father_Name` varchar(30) NOT NULL,
  `Course` varchar(30) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Year` int(10) NOT NULL,
  `Semester` int(10) NOT NULL,
  `Book_ID` int(10) NOT NULL,
  `Book_Name` varchar(30) NOT NULL,
  `Edition` int(10) NOT NULL,
  `Publisher` varchar(30) NOT NULL,
  `Price` int(10) NOT NULL,
  `Pages` int(10) NOT NULL,
  `Date_Of_Issue` date NOT NULL,
  `Return_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Return_Book`
--

LOCK TABLES `Return_Book` WRITE;
/*!40000 ALTER TABLE `Return_Book` DISABLE KEYS */;
INSERT INTO `Return_Book` VALUES (641,'java','Sajjan Lal','MCA','IT',2,4,8393,'java',1,'java',200,400,'2026-01-18','2012-04-17'),(641,'java','Sajjan Lal','MCA','IT',2,4,8393,'java',1,'java',200,400,'2026-01-18','2012-12-12'),(641,'java','Sajjan Lal','MCA','IT',2,4,8393,'java',1,'java',200,400,'2026-01-18','2012-12-12');
/*!40000 ALTER TABLE `Return_Book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student`
--

DROP TABLE IF EXISTS `Student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student` (
  `Student_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) NOT NULL,
  `Father_Name` varchar(40) NOT NULL,
  `Course` varchar(30) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Year` int(10) NOT NULL,
  `Semester` int(10) NOT NULL,
  PRIMARY KEY (`Student_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5595 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student`
--

LOCK TABLES `Student` WRITE;
/*!40000 ALTER TABLE `Student` DISABLE KEYS */;
INSERT INTO `Student` VALUES (641,'shiwakant','Sajjan Lal','MCA','IT',2,4),(1927,'Jai','Beeru','B Tech','CS',1,1),(5594,'Shiwakant','Sajjan Lal','MCA','Not Applicable',2,4);
/*!40000 ALTER TABLE `Student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shiwa`
--

DROP TABLE IF EXISTS `shiwa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shiwa` (
  `Rollno` varchar(10) DEFAULT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `sex` char(6) DEFAULT NULL,
  `birth` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shiwa`
--

LOCK TABLES `shiwa` WRITE;
/*!40000 ALTER TABLE `shiwa` DISABLE KEYS */;
INSERT INTO `shiwa` VALUES ('111','jai','Male','1995-02-01');
/*!40000 ALTER TABLE `shiwa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 22:18:12
